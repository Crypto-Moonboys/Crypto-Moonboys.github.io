# NBG London — Dark Industrial Sound Inventory and Integration Notes

Audited against `game/nbg-level1.js` on GitHub `main` (29 Oct 2026). Assets are original synthesised prototypes, not recordings from third parties. No game code changed.

## Confirmed mechanics
- Player: run start, first jump, double jump, third-jump backflip, landing, spray action, falling and damage.
- Combat: rat attack variants, landed and descending parachute rat, Graffbot flame, Balloon Girl release, enemy defeat/stomp, flying pigeon/pig.
- Rewards: coin tiers and combo, secret coins, speed box, mystery/star boxes, health restore, checkpoints.
- Game flow: level completion, game over, interface actions, ranked result feedback.

## Game event integration hooks verified in source
- `nbg-xp-collected`: `coin_small`, tier-based coin variants; `nbg-secret-found`: `secret_found`.
- `nbg-speed-boost`: `speed_boost_pickup`; `nbg-reward-found`: `mystery_box` / `star_box` / `health_restore`.
- `nbg-enemy-defeated`: `enemy_defeat` (use `enemy_stomp` when `reason=stomp`).
- `nbg-player-hit`: `player_hurt`; `nbg-checkpoint`: `checkpoint`.

## Events needing new presentation-only hooks
- Jump branches in `updatePlayer` for `jump_1`, `jump_2`, `jump_3_backflip`; detect transition into grounded for landing.
- Spray transition from ready to active: `spray_attack` once per attack, never each frame.
- Graffbot fire begins at `fireStartedAt`; Balloon Girl changes state to `release`; rat starts its attack; parachute rat spawns/lands.
- Level complete and game over transitions: trigger once per run; server result accepted/rejected should trigger only when verified.
- UI menu states, pause/resume, low-health threshold, and boost expiration need explicit state transitions.

## Playback safety
- Do not change worker-scored simulation, replay, XP, movement, collision or event payloads.
- Keep audio completely presentation-only; use `AudioContext` unlocked from actual pointer/key input (Telegram/mobile autoplay restriction).
- Preload compressed OGG, manage polyphony (especially coin collect spam); cap simultaneous voices and rate-limit warnings.
- Separate music and SFX gain, enable mute, honour reduced sound preference, suspend/resume on hidden tab and pause.
- Trigger once on **state transitions** rather than each render/update frame; ensure replay remains deterministic and audio cannot change game outcome.
- Assets are intentionally dry and low-mid focused; audition on small phone speakers and adjust sub-bass attenuation.

## Naming and export
- 42 effects, WAV reference masters at 32kHz mono PCM16 and small OGG files for deployment.
- `manifest.json` maps exact effect keys to relative deploy paths.
- `main_theme_dark_industrial_loop.ogg` is a copy of the previously approved theme where available.
