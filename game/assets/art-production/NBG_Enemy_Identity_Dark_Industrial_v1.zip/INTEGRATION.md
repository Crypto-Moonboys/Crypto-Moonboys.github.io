# NBG London — Enemy audio identity v1

These 17 new original audio identities supplement, not replace, the 42 existing combat and reward SFX. All are mastered with subdued highs and a dark industrial character. Use OGG in the live game, retain WAV masters.

## Explicit enemy mapping
- `bot` moving: `graffbot_walk` (nearby loop); idle: `graffbot_idle` (optional); initial detection: `graffbot_spot`. Preserve `graffbot_fire` and `graffbot_hurt`.
- `rat` moving: `london_rat_walk`; detection: `london_rat_alert`. Preserve attacks/death.
- `parachuteRatA/B/C` airborne: corresponding `_descent` loops, all different. Existing parachute drop/landing one-shots still play. On landing, B/A become `brownRat`, C becomes `turquoiseRat`.
- `brownRat` moving: `brown_rat_walk`, detection: `brown_rat_alert`.
- `turquoiseRat` moving: `turquoise_rat_walk`, detection: `turquoise_rat_alert`.
- `balloon` moving: `balloon_girl_walk`; near-player ambient identity: `balloon_girl_presence`; notice: `balloon_girl_spot`. Keep balloon release/burst.
- `pigeon` flight: `pigeon_flight`; passing or nearby call: `pigeon_call`.

## Runtime safety / mix
Loop files require a per-entity voice controller keyed to enemy object identity, and proximity gating with falloff from the listener/camera. Do NOT fire loops on every frame; start when near and moving, update gain, stop on death, enemy despawn, distant culling, pause, reset and page exit. Cap total persistent enemy loops to 2–3, keep at most one audible identity for any enemy, and duck below music and combat by default. Stagger/phase neighboring enemy loops to avoid repetition.

The current scoring/replay Worker must not consume audio state. Avoid adding sound state to serialised deterministic simulation. Existing shared `NBGAudio` manager only exposes one-shot playEffect; create separate optional loop handles or extend it with keyed proximity voice management safely, with tests. Special handling: `parachute_rat_a/b/c_descent` should track the selected sprite, not a generic `parachute_rat_drop` event; airborne A and B both become brown when landed.

## QA
Verify each sprite variant with its own identity sound; check mobile sound unlock, room volume, audio budget, pause/visibility, collision/replay parity, and mute persistence. Avoid continuous sound from off-screen enemies.
